/** Test Class
 * Ethan Tindall
 * CS 246
 */

package tindall;

import java.util.Scanner;

public class Test {

    public static void main(String[] args) throws Exception {
        //repeat loop if password does not meet expectations
        while (true) {
            //initialize variables
            User user1;
            boolean complex;
            Scanner input = new Scanner(System.in);

            //take input
            System.out.print("Enter a password: ");
            String pw = input.nextLine();
            user1 = new User(pw);
            complex = user1.isComplex(user1.getPassword());

            //try catch loop to determine if password is complex
            try {
                //if password complex
                if (user1.getPassword().length() > 7 && complex == true) {
                    //hash password
                    System.out.println("Password: " + user1.getPassword());
                    System.out.println("Salt: " + user1.getSalt());
                    System.out.println("Hash: " + user1.getHash());

                    NSALoginController.hashUserPassword(user1);
                    System.out.println("\nPassword has been hashed.\n");

                    System.out.println("Password: " + user1.getHashedPassword());
                    System.out.println("Salt: " + user1.getSalt());
                    System.out.println("Hash: " + user1.getHash() + "\n");

                    System.out.println("Please enter your password again: ");
                    String verified = input.nextLine();
                    user1.setPassword(verified);
                    if (NSALoginController.verifyPassword(user1) == true) {
                        System.out.println("Correct password");
                    }
                    else {
                        System.out.println("Incorrect password");
                    }

                    break;
                } else {
                    throw new WeakPasswordException("Try again.");
                }


            } catch (WeakPasswordException e){
                System.out.println("The password is not complicated enough. Please try again.");
            }

        }





    }
}