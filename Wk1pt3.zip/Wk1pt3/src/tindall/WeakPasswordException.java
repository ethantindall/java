/**Weak password exception Class
 * Ethan Tindall
 * CS 246
 */

package tindall;

class WeakPasswordException extends Exception {
    public WeakPasswordException(String s) {
        super(s);
    }
}
