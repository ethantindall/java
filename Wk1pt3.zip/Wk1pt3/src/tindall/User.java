/**Wk 1 Security Assignment User class
 * Ethan Tindall
 * CS246
 */
package tindall;

public class User {
    private String password;
    private String salt;
    private String hash;
    private String hashedpw;

    /**
     * Constructor class
     * @param pw
     * @throws WeakPasswordException
     */

        public User(String pw) throws WeakPasswordException{
            password = pw;
    }

    /**
     * isComplex method
     * @param pw
     * @return boolean
     */
    public boolean isComplex(String pw) {
        for (int i = 0; i < pw.length(); i++) {
            if (Character.isDigit(pw.charAt(i)) == true) {
                return true;
            }
        }
        return false;
    }



    //SETTERS

    /**
     * Set password method
     * @param p
     */
    public void setPassword(String p) {
        password = p;
    }

    /**
     * Set salt method
     * @param s
     */
    public void setSalt(String s) {
        salt = s;
    }

    /**
     * Set hash method
     * @param h
     */
    public void setHash(String h) {
        hash = h;
    }

    /**
     * Set hashed password method
     * @param hashString
     */
    public void setHashedPassword(String hashString) {
        setHash(hashString);
    }
    //GETTERS

    /**
     * Get password method
     * @return password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Get salt method
     * @return salt
     */
    public String getSalt() {
        return salt;
    }

    /**
     * Get hash method
     * @return hash
     */
    public String getHash() {
        return hash;
    }

    /**
     * Get hashed password method
     * @return getHash()
     */
    public String getHashedPassword() {
        return getHash();
    }
}


