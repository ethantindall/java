package tindall;

enum Destination {
    Mexico, Europe, Japan;}
