package tindall;

public interface Expense {
    float getCost();
}