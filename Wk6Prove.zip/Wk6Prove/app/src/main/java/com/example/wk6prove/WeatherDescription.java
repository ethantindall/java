package com.example.wk6prove;

public class WeatherDescription {
    private String description;

    public String getDescription() { return description;}
}
