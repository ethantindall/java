package com.example.wk6prove;

public class WeatherWind {
    private float speed;
    public float getSpeed() {return speed;}
}
