package prove02;

public interface Roamer {
    public void roam();
}